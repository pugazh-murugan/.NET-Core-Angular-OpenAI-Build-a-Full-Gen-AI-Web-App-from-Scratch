namespace FirstRagApp.Models;

public class UploadFileResponse
{
    public bool Success { get; set; }
    public string FileName { get; set; } = string.Empty;
    public string BlobUrl { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
}

public class ChatRequest
{
    /// <summary>Question typed by the user in the chat UI.</summary>
    public string Question { get; set; } = string.Empty;

    /// <summary>
    /// Optional: restrict search to one or more previously uploaded documents.
    /// Empty/null = search across all indexed documents.
    /// </summary>
    public List<string>? DocumentNames { get; set; }
}

public class ChatResponse
{
    public string Answer { get; set; } = string.Empty;
    public List<string> SourceChunks { get; set; } = new();
    public string Model { get; set; } = string.Empty;
}
