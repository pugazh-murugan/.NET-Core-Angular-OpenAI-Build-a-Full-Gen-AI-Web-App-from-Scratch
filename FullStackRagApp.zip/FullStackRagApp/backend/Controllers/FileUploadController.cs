using FirstRagApp.Models;
using FirstRagApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace FirstRagApp.Controllers;

[ApiController]
[Route("api/[controller]")]
public class FileUploadController : ControllerBase
{
    private readonly IBlobStorageService _blobStorageService;
    private readonly ILogger<FileUploadController> _logger;

    // Matches the "supported formats" mentioned on the upload screen in the demo.
    private static readonly HashSet<string> AllowedExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".pdf", ".doc", ".docx", ".ppt", ".pptx", ".txt", ".png", ".jpg", ".jpeg"
    };

    private const long MaxFileSizeBytes = 25 * 1024 * 1024; // 25 MB

    public FileUploadController(IBlobStorageService blobStorageService, ILogger<FileUploadController> logger)
    {
        _blobStorageService = blobStorageService;
        _logger = logger;
    }

    /// <summary>
    /// POST api/fileupload
    /// Called by the Angular "upload document" screen. Stores the file in Blob Storage;
    /// the Azure AI Search indexer (5-minute schedule) picks it up automatically.
    /// </summary>
    [HttpPost]
    [RequestSizeLimit(MaxFileSizeBytes)]
    public async Task<ActionResult<UploadFileResponse>> UploadDocument(IFormFile file)
    {
        if (file is null || file.Length == 0)
        {
            return BadRequest(new UploadFileResponse { Success = false, Message = "No file was provided." });
        }

        var extension = Path.GetExtension(file.FileName);
        if (!AllowedExtensions.Contains(extension))
        {
            return BadRequest(new UploadFileResponse
            {
                Success = false,
                Message = $"Unsupported file type '{extension}'. Allowed: {string.Join(", ", AllowedExtensions)}"
            });
        }

        try
        {
            await using var stream = file.OpenReadStream();
            var blobUrl = await _blobStorageService.UploadFileAsync(stream, file.FileName, file.ContentType);

            return Ok(new UploadFileResponse
            {
                Success = true,
                FileName = file.FileName,
                BlobUrl = blobUrl,
                Message = "File uploaded successfully. It will be indexed within a few minutes."
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "File upload failed for {FileName}", file.FileName);
            return StatusCode(500, new UploadFileResponse { Success = false, Message = "Upload failed. Check server logs." });
        }
    }
}
