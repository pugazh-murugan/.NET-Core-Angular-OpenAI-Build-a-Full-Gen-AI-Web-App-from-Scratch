using FirstRagApp.Models;
using FirstRagApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace FirstRagApp.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ChatController : ControllerBase
{
    private readonly IAzureSearchService _searchService;
    private readonly IAzureOpenAIService _openAIService;
    private readonly ILogger<ChatController> _logger;

    public ChatController(
        IAzureSearchService searchService,
        IAzureOpenAIService openAIService,
        ILogger<ChatController> logger)
    {
        _searchService = searchService;
        _openAIService = openAIService;
        _logger = logger;
    }

    /// <summary>
    /// POST api/chat
    /// This is the orchestrator described in the video's architecture diagram:
    /// User question -> Azure AI Search (retriever) -> combine with question -> Azure OpenAI GPT-4 -> answer.
    /// </summary>
    [HttpPost]
    public async Task<ActionResult<ChatResponse>> Ask([FromBody] ChatRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Question))
        {
            return BadRequest("Question cannot be empty.");
        }

        try
        {
            // Step 1: Retriever - pull relevant chunks from indexed documents
            var chunks = await _searchService.GetRelevantChunksAsync(request.Question, request.DocumentNames);

            // Step 2: Orchestrator combines question + retrieved context,
            //         sends to GPT-4 for a grounded, contextual answer
            var answer = await _openAIService.GetChatResponseAsync(request.Question, chunks);

            return Ok(new ChatResponse
            {
                Answer = answer,
                SourceChunks = chunks,
                Model = "gpt-4"
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Chat request failed for question: {Question}", request.Question);
            return StatusCode(500, "Something went wrong while generating the response.");
        }
    }
}
