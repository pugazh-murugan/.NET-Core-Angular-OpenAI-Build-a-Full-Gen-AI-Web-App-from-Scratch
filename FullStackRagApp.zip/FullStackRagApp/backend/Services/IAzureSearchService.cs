namespace FirstRagApp.Services;

public interface IAzureSearchService
{
    /// <summary>
    /// Retrieves the most relevant chunks from the indexed documents for the given question.
    /// Optionally scoped to specific source document names.
    /// </summary>
    Task<List<string>> GetRelevantChunksAsync(string question, List<string>? documentNames = null, int topK = 5);
}
