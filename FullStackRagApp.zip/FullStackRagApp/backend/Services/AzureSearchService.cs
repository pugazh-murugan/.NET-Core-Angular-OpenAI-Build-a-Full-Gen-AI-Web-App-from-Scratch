using Azure;
using Azure.Search.Documents;
using Azure.Search.Documents.Models;

namespace FirstRagApp.Services;

public class AzureSearchService : IAzureSearchService
{
    private readonly SearchClient _searchClient;
    private readonly ILogger<AzureSearchService> _logger;

    // These field names match the DEFAULT index created by the Azure portal's
    // "Import data" wizard when you point it at a blob storage container.
    // If you customized your index schema, update these two constants.
    private const string ContentField = "content";
    private const string SourceFileField = "metadata_storage_name";

    public AzureSearchService(IConfiguration config, ILogger<AzureSearchService> logger)
    {
        _logger = logger;

        var endpoint = config["AzureSearch:Endpoint"]
            ?? throw new InvalidOperationException("AzureSearch:Endpoint is not configured.");
        var indexName = config["AzureSearch:IndexName"]
            ?? throw new InvalidOperationException("AzureSearch:IndexName is not configured.");
        var apiKey = config["AzureSearch:ApiKey"]
            ?? throw new InvalidOperationException("AzureSearch:ApiKey is not configured.");

        _searchClient = new SearchClient(new Uri(endpoint), indexName, new AzureKeyCredential(apiKey));
    }

    public async Task<List<string>> GetRelevantChunksAsync(string question, List<string>? documentNames = null, int topK = 5)
    {
        var options = new SearchOptions
        {
            Size = topK,
            Select = { ContentField, SourceFileField }
        };

        // Restrict search to specific uploaded documents, if the user selected any
        // (mirrors the "select one document or select all documents" behavior in the UI).
        if (documentNames is { Count: > 0 })
        {
            var filterClauses = documentNames.Select(name => $"{SourceFileField} eq '{name}'");
            options.Filter = string.Join(" or ", filterClauses);
        }

        _logger.LogInformation("Searching index for question: {Question}", question);

        Response<SearchResults<SearchDocument>> response =
            await _searchClient.SearchAsync<SearchDocument>(question, options);

        var chunks = new List<string>();

        await foreach (SearchResult<SearchDocument> result in response.Value.GetResultsAsync())
        {
            if (result.Document.TryGetValue(ContentField, out var content) && content is string text)
            {
                chunks.Add(text);
            }
        }

        _logger.LogInformation("Retrieved {Count} relevant chunks", chunks.Count);
        return chunks;
    }
}
