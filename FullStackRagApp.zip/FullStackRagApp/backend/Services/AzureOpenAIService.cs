using Azure;
using Azure.AI.OpenAI;

namespace FirstRagApp.Services;

public class AzureOpenAIService : IAzureOpenAIService
{
    private readonly OpenAIClient _client;
    private readonly string _deploymentName;
    private readonly ILogger<AzureOpenAIService> _logger;

    public AzureOpenAIService(IConfiguration config, ILogger<AzureOpenAIService> logger)
    {
        _logger = logger;

        var endpoint = config["AzureOpenAI:Endpoint"]
            ?? throw new InvalidOperationException("AzureOpenAI:Endpoint is not configured.");
        var apiKey = config["AzureOpenAI:ApiKey"]
            ?? throw new InvalidOperationException("AzureOpenAI:ApiKey is not configured.");
        _deploymentName = config["AzureOpenAI:DeploymentName"]
            ?? throw new InvalidOperationException("AzureOpenAI:DeploymentName is not configured.");

        _client = new OpenAIClient(new Uri(endpoint), new AzureKeyCredential(apiKey));
    }

    public async Task<string> GetChatResponseAsync(string question, List<string> contextChunks)
    {
        if (contextChunks.Count == 0)
        {
            return "I couldn't find anything relevant in the uploaded documents to answer that question.";
        }

        var context = string.Join("\n\n---\n\n", contextChunks);

        var systemMessage = "You are an AI assistant that helps users retrieve accurate answers strictly " +
                             "based on the context extracted from their uploaded documents. If the answer " +
                             "is not present in the context, say you don't have enough information.";

        var userMessage = $"Context:\n{context}\n\nQuestion: {question}";

        var chatOptions = new ChatCompletionsOptions
        {
            DeploymentName = _deploymentName,
            Messages =
            {
                new ChatRequestSystemMessage(systemMessage),
                new ChatRequestUserMessage(userMessage)
            },
            Temperature = 0.3f,
            MaxTokens = 800
        };

        _logger.LogInformation("Sending question + {ChunkCount} context chunks to Azure OpenAI", contextChunks.Count);

        Response<ChatCompletions> response = await _client.GetChatCompletionsAsync(chatOptions);

        return response.Value.Choices[0].Message.Content;
    }
}
