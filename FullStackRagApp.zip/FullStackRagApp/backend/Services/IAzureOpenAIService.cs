namespace FirstRagApp.Services;

public interface IAzureOpenAIService
{
    /// <summary>
    /// Sends the user question plus retrieved context chunks to GPT-4 and returns a grounded answer.
    /// </summary>
    Task<string> GetChatResponseAsync(string question, List<string> contextChunks);
}
