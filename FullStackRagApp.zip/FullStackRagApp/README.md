# Full-Stack Gen AI RAG App — .NET Core + Angular + Azure OpenAI

Two folders, one system:

- `backend/`  — ASP.NET Core Web API (.NET 8). Blob Storage upload, Azure AI Search retrieval,
  Azure OpenAI (GPT-4) generation. See `backend/README.md`.
- `frontend/` — Angular 19 standalone-components app. Upload UI + chat UI. See `frontend/README.md`.

## Quick start
1. Create the 3 Azure resources (Storage Account + container, Azure AI Search index over
   that container, Azure OpenAI with a GPT-4 deployment) — see `backend/README.md` step 1.
2. `backend/appsettings.json` — fill in your connection strings/keys.
3. `cd backend && dotnet run` — API starts on `https://localhost:5001` (check your launch profile).
4. `cd frontend && npm install && npm start` — Angular app starts on `http://localhost:4200`.
5. Open `http://localhost:4200`, upload a document, wait a few minutes for indexing, then
   go to Chat and ask about it.

## Architecture
```
Angular (upload/chat UI)
   │  HTTP (JSON / multipart)
   ▼
ASP.NET Core Web API
   │
   ├── Blob Storage        (raw document files)
   ├── Azure AI Search      (retriever — indexes & searches chunks)
   └── Azure OpenAI GPT-4   (generator — answers grounded in retrieved chunks)
```
