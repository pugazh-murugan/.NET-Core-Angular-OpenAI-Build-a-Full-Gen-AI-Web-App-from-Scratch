# First RAG App — Angular Frontend

Angular 19 (standalone components) frontend for the RAG app. Talks to the
`FirstRagApp` ASP.NET Core Web API in the sibling folder.

## Structure
```
src/app/
├── components/
│   ├── header/            # Nav bar: Upload Document | Start Chatting
│   ├── footer/
│   ├── home/               # Landing page
│   ├── document-upload/    # Drag-and-drop upload -> POST /api/fileupload
│   └── chat/                # Chat UI -> POST /api/chat
├── services/rag-api.service.ts   # HttpClient wrapper for both endpoints
├── app.routes.ts
├── app.config.ts            # provideHttpClient + provideRouter
└── app.component.ts          # Root shell
```

## 1. Prerequisites
- Node.js 22+
- Angular CLI 19: `npm install -g @angular/cli@19`

## 2. Point the frontend at your backend
Edit `src/environments/environment.ts`:
```ts
export const environment = {
  production: false,
  apiUrl: 'https://localhost:5001/api'   // match your FirstRagApp API's launch URL
};
```

## 3. Install & run
```bash
npm install
npm start          # ng serve, opens on http://localhost:4200
```

## 4. Usage
1. Go to **Upload Document** — drag & drop or browse a file (pdf, doc/docx, ppt/pptx, txt, png, jpg).
   It's uploaded to Blob Storage via the API; Azure AI Search indexes it within ~5 minutes.
2. Go to **Start Chatting** — ask a question. The API retrieves relevant chunks from
   Azure AI Search and returns a GPT-4 generated answer, with source chunks shown in a
   collapsible "N source chunk(s) used" section under each reply.

## Notes
- CORS on the backend (`Program.cs`) is already set to allow `http://localhost:4200`.
- For production, build with `npm run build` and update `environment.prod.ts` with your
  deployed API URL, then host the `dist/` output (e.g. Azure Static Web Apps, Blob Storage
  static website, or behind the same App Service as the API).
