import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface UploadFileResponse {
  success: boolean;
  fileName: string;
  blobUrl: string;
  message: string;
}

export interface ChatRequest {
  question: string;
  documentNames?: string[];
}

export interface ChatResponse {
  answer: string;
  sourceChunks: string[];
  model: string;
}

@Injectable({ providedIn: 'root' })
export class RagApiService {
  private readonly apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  /** Uploads a file to the backend, which stores it in Blob Storage. */
  uploadDocument(file: File): Observable<UploadFileResponse> {
    const formData = new FormData();
    formData.append('file', file, file.name);
    return this.http.post<UploadFileResponse>(`${this.apiUrl}/fileupload`, formData);
  }

  /** Sends a question (optionally scoped to specific documents) to the RAG chat endpoint. */
  askQuestion(request: ChatRequest): Observable<ChatResponse> {
    return this.http.post<ChatResponse>(`${this.apiUrl}/chat`, request);
  }
}
