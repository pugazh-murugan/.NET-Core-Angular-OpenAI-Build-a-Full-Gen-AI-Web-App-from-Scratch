import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { DocumentUploadComponent } from './components/document-upload/document-upload.component';
import { ChatComponent } from './components/chat/chat.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'documents', component: DocumentUploadComponent },
  { path: 'chat', component: ChatComponent },
  { path: '**', redirectTo: '' }
];
