import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RagApiService } from '../../services/rag-api.service';

interface ChatMessage {
  role: 'user' | 'assistant';
  text: string;
  sourceChunks?: string[];
}

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container">
      <div class="card chat-card">
        <h2>Chat with your documents</h2>

        <div class="messages">
          <div *ngFor="let msg of messages" class="message" [class.user]="msg.role === 'user'">
            <p>{{ msg.text }}</p>
            <details *ngIf="msg.sourceChunks?.length">
              <summary>{{ msg.sourceChunks!.length }} source chunk(s) used</summary>
              <p *ngFor="let chunk of msg.sourceChunks" class="chunk">{{ chunk }}</p>
            </details>
          </div>
          <div *ngIf="isLoading" class="message assistant loading">Thinking…</div>
        </div>

        <form class="composer" (submit)="sendMessage($event)">
          <input
            type="text"
            [(ngModel)]="currentQuestion"
            name="question"
            placeholder="Ask a question about your uploaded documents…"
            [disabled]="isLoading" />
          <button type="submit" class="btn" [disabled]="isLoading || !currentQuestion.trim()">Send</button>
        </form>
      </div>
    </div>
  `,
  styles: [`
    .chat-card { display: flex; flex-direction: column; height: 70vh; }
    .messages { flex: 1; overflow-y: auto; display: flex; flex-direction: column; gap: 10px; padding: 8px 0; }
    .message { max-width: 75%; padding: 10px 14px; border-radius: 12px; background: #f5f6fa; align-self: flex-start; }
    .message.user { align-self: flex-end; background: #4a5cff; color: #fff; }
    .message p { margin: 0; white-space: pre-wrap; }
    .message.loading { font-style: italic; color: #6b7080; }
    .chunk { font-size: 0.85rem; color: #6b7080; border-left: 3px solid #c3c7db; padding-left: 8px; margin: 6px 0; }
    .composer { display: flex; gap: 10px; margin-top: 14px; }
    .composer input { flex: 1; padding: 10px 14px; border-radius: 8px; border: 1px solid #c3c7db; }
  `]
})
export class ChatComponent {
  currentQuestion = '';
  messages: ChatMessage[] = [];
  isLoading = false;

  constructor(private ragApi: RagApiService) {}

  sendMessage(event: Event): void {
    event.preventDefault();
    const question = this.currentQuestion.trim();
    if (!question || this.isLoading) return;

    this.messages.push({ role: 'user', text: question });
    this.currentQuestion = '';
    this.isLoading = true;

    this.ragApi.askQuestion({ question }).subscribe({
      next: (res) => {
        this.messages.push({ role: 'assistant', text: res.answer, sourceChunks: res.sourceChunks });
        this.isLoading = false;
      },
      error: () => {
        this.messages.push({ role: 'assistant', text: 'Something went wrong. Please check the API connection and try again.' });
        this.isLoading = false;
      }
    });
  }
}
