import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RagApiService } from '../../services/rag-api.service';

interface UploadedDocEntry {
  name: string;
  status: 'uploading' | 'done' | 'error';
  message?: string;
}

const ALLOWED_EXTENSIONS = ['.pdf', '.doc', '.docx', '.ppt', '.pptx', '.txt', '.png', '.jpg', '.jpeg'];

@Component({
  selector: 'app-document-upload',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container">
      <div class="card">
        <h2>Upload Document</h2>
        <p class="hint">Supported formats: {{ allowedExtensions.join(', ') }}</p>

        <div
          class="dropzone"
          [class.dragging]="isDragging"
          (dragover)="onDragOver($event)"
          (dragleave)="onDragLeave($event)"
          (drop)="onDrop($event)"
          (click)="fileInput.click()">
          <p>Drag &amp; drop a file here, or click to browse</p>
          <input #fileInput type="file" hidden (change)="onFileSelected($event)" [accept]="allowedExtensions.join(',')" />
        </div>

        <ul class="doc-list" *ngIf="uploadedDocs.length">
          <li *ngFor="let doc of uploadedDocs" [class]="doc.status">
            <span class="name">{{ doc.name }}</span>
            <span class="status">{{ statusLabel(doc) }}</span>
          </li>
        </ul>
      </div>
    </div>
  `,
  styles: [`
    .hint { color: #6b7080; font-size: 0.9rem; }
    .dropzone {
      margin-top: 16px;
      border: 2px dashed #c3c7db;
      border-radius: 12px;
      padding: 48px 16px;
      text-align: center;
      cursor: pointer;
      color: #6b7080;
      transition: border-color 0.15s ease, background 0.15s ease;
    }
    .dropzone.dragging { border-color: #4a5cff; background: #eef0ff; }
    .doc-list { list-style: none; padding: 0; margin-top: 20px; }
    .doc-list li { display: flex; justify-content: space-between; padding: 10px 12px; border-radius: 8px; background: #f5f6fa; margin-bottom: 8px; }
    .doc-list li.error { background: #fde8e8; color: #b42318; }
    .doc-list li.done { background: #e8f7ee; color: #12793f; }
  `]
})
export class DocumentUploadComponent {
  allowedExtensions = ALLOWED_EXTENSIONS;
  isDragging = false;
  uploadedDocs: UploadedDocEntry[] = [];

  constructor(private ragApi: RagApiService) {}

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    this.isDragging = true;
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault();
    this.isDragging = false;
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    this.isDragging = false;
    const files = event.dataTransfer?.files;
    if (files?.length) {
      this.processFile(files[0]);
    }
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files?.length) {
      this.processFile(input.files[0]);
    }
    input.value = '';
  }

  private processFile(file: File): void {
    const extension = '.' + file.name.split('.').pop()?.toLowerCase();
    if (!this.allowedExtensions.includes(extension)) {
      this.uploadedDocs.unshift({ name: file.name, status: 'error', message: 'Unsupported file type' });
      return;
    }

    const entry: UploadedDocEntry = { name: file.name, status: 'uploading' };
    this.uploadedDocs.unshift(entry);

    this.ragApi.uploadDocument(file).subscribe({
      next: (res) => {
        entry.status = res.success ? 'done' : 'error';
        entry.message = res.message;
      },
      error: () => {
        entry.status = 'error';
        entry.message = 'Upload failed. Check the API connection.';
      }
    });
  }

  statusLabel(doc: UploadedDocEntry): string {
    if (doc.status === 'uploading') return 'Uploading…';
    if (doc.status === 'done') return 'Indexed';
    return doc.message ?? 'Error';
  }
}
