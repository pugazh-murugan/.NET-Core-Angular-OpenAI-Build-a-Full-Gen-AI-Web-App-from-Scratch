import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="container">
      <section class="card hero">
        <h1>Chat with your own documents</h1>
        <p>
          Upload PDFs, Word files, PowerPoint decks, or images. Azure AI Search indexes them,
          and Azure OpenAI (GPT-4) answers your questions using only your uploaded content.
        </p>
        <div class="actions">
          <a routerLink="/documents" class="btn">Upload Document</a>
          <a routerLink="/chat" class="btn secondary">Start Chatting</a>
        </div>
      </section>

      <section class="card how-it-works">
        <h2>How it works</h2>
        <ol>
          <li>Upload a document — it's stored securely in Azure Blob Storage.</li>
          <li>Azure AI Search indexes and chunks the content automatically.</li>
          <li>Ask a question — the system retrieves the most relevant chunks.</li>
          <li>Azure OpenAI generates a grounded, contextual answer from those chunks.</li>
        </ol>
      </section>
    </div>
  `,
  styles: [`
    .hero { text-align: center; padding: 40px 24px; }
    .hero h1 { margin-top: 0; }
    .actions { margin-top: 20px; display: flex; gap: 12px; justify-content: center; }
    .btn.secondary { background: #fff; color: #4a5cff; border: 2px solid #4a5cff; }
    .btn.secondary:hover { background: #eef0ff; }
    .how-it-works { margin-top: 24px; }
    .how-it-works ol { line-height: 1.8; }
  `]
})
export class HomeComponent {}
