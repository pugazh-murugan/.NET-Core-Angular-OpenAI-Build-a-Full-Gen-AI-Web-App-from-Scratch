import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  template: `
    <header class="header">
      <div class="header-inner container">
        <a routerLink="/" class="brand">🧠 First RAG App</a>
        <nav class="nav">
          <a routerLink="/documents" routerLinkActive="active">Upload Document</a>
          <a routerLink="/chat" routerLinkActive="active">Start Chatting</a>
        </nav>
      </div>
    </header>
  `,
  styles: [`
    .header { background: #1f2430; color: #fff; }
    .header-inner { display: flex; align-items: center; justify-content: space-between; padding: 14px 16px; }
    .brand { font-weight: 700; font-size: 1.1rem; }
    .nav { display: flex; gap: 20px; }
    .nav a { opacity: 0.8; font-weight: 500; }
    .nav a.active, .nav a:hover { opacity: 1; }
  `]
})
export class HeaderComponent {}
