import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  standalone: true,
  template: `
    <footer class="footer">
      <p class="container">Built with .NET Core, Angular &amp; Azure OpenAI — First RAG App demo.</p>
    </footer>
  `,
  styles: [`
    .footer { border-top: 1px solid #e3e5ee; margin-top: 40px; color: #6b7080; font-size: 0.9rem; }
  `]
})
export class FooterComponent {}
